package com.cognizant.ridesharingplatform.vehiclemanagement.exceptions;

public class InvalidDocumentException extends Exception {

	public InvalidDocumentException(String exception) {
		super(exception);
	}

}
