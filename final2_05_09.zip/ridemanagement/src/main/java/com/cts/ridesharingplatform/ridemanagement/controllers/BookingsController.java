package com.cts.ridesharingplatform.ridemanagement.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.entities.Bookings;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingAlreadyExistException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingNotFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaxSeatsPerRideExceededException;
import com.cts.ridesharingplatform.ridemanagement.services.BookingsService;


@RestController
public class BookingsController {

	@Autowired
	private BookingsService bookingsService;

	@GetMapping("/bookings")
	public List<Bookings> getAllBookings() {
		return this.bookingsService.getAllBookings();
	}

	// d.Insert a new booking and get the status code and bookingId if the booking is created
	@PostMapping(path = "/api/rides/book", consumes = "application/json")
	public ResponseEntity<Integer> createBooking(@Valid @RequestBody Bookings bookings) throws BookingAlreadyExistException,MaxSeatsPerRideExceededException {
		Bookings booking = this.bookingsService.createBooking(bookings);
		int bookingid=booking.getBookingId();
		return new ResponseEntity<Integer>(bookingid, HttpStatus.CREATED);
	}

	// e.Search existing bookings for user

	@GetMapping("/search/{rideruserid}")
	public ResponseEntity<List<Bookings>> searchBookingByRiderUserId(@PathVariable int rideruserid) throws BookingNotFoundException {
		List<Bookings> bookings=bookingsService.searchBookingByRiderUserId(rideruserid);
		return new ResponseEntity<>(bookings, HttpStatus.OK);
		
	}

}
