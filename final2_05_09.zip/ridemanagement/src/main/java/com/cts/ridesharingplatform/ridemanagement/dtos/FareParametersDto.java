package com.cts.ridesharingplatform.ridemanagement.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FareParametersDto {
	
	private int distance;
	
	private String registrationNo;
	

}
