package com.cts.ridesharingplatform.ridemanagement.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;

public interface RideSchedulesRepository extends CrudRepository<RideSchedules, Integer> {

	
	//c.Search a ride schedule by using from to and available seats
	RideSchedules findRideByRideFromAndRideToAndNoOfSeatsAvailable(String rideFrom, String rideTo,
			int noOfSeatsAvailable);

}
