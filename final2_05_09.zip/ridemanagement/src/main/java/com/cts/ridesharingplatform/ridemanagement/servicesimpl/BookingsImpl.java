package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ridesharingplatform.ridemanagement.entities.Bookings;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingAlreadyExistException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingNotFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaxSeatsPerRideExceededException;
import com.cts.ridesharingplatform.ridemanagement.repos.BookingsRepository;
import com.cts.ridesharingplatform.ridemanagement.services.BookingsService;


@Service
public class BookingsImpl implements BookingsService {

	@Autowired
	BookingsRepository bookingsRepository;

	@Override
	public List<Bookings> getAllBookings() {
		// TODO Auto-generated method stub
		return (List<Bookings>) bookingsRepository.findAll();
	}

	// d.Insert a new booking
	@Override
	public Bookings createBooking(Bookings bookings)
			throws BookingAlreadyExistException, MaxSeatsPerRideExceededException {
		// TODO Auto-generated method stub
		Bookings boo;
		int seats = bookings.getNoOfSeats();
		if (bookingsRepository.existsById(bookings.getBookingId())) {
			throw new BookingAlreadyExistException();
		}
		else {
			if(seats <= 2) {
				boo = bookingsRepository.save(bookings);
			} 
			else {
				throw new MaxSeatsPerRideExceededException();
			}
		}
		return boo;

	}

	@Override
	public List<Bookings> searchBookingByRiderUserId(int riderUserId) throws BookingNotFoundException {
		List<Bookings> bookings=bookingsRepository.findByRiderUserId(riderUserId);
		if(bookings.isEmpty()) {
			throw new BookingNotFoundException();
		}
		
		return bookings;
	}

	

}
