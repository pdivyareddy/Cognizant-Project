package com.cts.ridesharingplatform.ridemanagement.services;

import java.util.List;

import com.cts.ridesharingplatform.ridemanagement.entities.Bookings;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingAlreadyExistException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingNotFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaxSeatsPerRideExceededException;

public interface BookingsService {
	List <Bookings> getAllBookings();
	
	// d.Insert a new booking
	Bookings createBooking(Bookings bookings)throws BookingAlreadyExistException,MaxSeatsPerRideExceededException;
	
	//e.Search existing bookings for user
	List<Bookings> searchBookingByRiderUserId(int riderUserId)throws BookingNotFoundException;

}
