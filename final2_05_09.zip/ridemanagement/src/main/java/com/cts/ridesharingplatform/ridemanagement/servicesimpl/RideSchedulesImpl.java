package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaximumCapacityExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.VehicleNotApprovedException;
import com.cts.ridesharingplatform.ridemanagement.mapper.RideSchedulesMapper;
import com.cts.ridesharingplatform.ridemanagement.repos.RideSchedulesRepository;
import com.cts.ridesharingplatform.ridemanagement.repos.VehiclesRepository;
import com.cts.ridesharingplatform.ridemanagement.services.RideSchedulesService;

@Service
public class RideSchedulesImpl implements RideSchedulesService {

	@Autowired
	RideSchedulesRepository rideSchedulesRepository;
	@Autowired
	VehiclesRepository vehiclesRepository;

	// Lists all rideschedules
	public List<RideSchedules> getAllRideSchedules() {
		return (List<RideSchedules>) rideSchedulesRepository.findAll();
	}

	// b.Insert a new RideSchedule
	
	// Gives rideschedules details by using Id
	@Override
	public RideSchedules getRideById(int ID) {
		return rideSchedulesRepository.findById(ID).get();
	}

	//c. Search a ride schedule by using from to and available seats
	@Override
	public RideSchedules getRideByRideFromAndRideToAndNoOfSeatsAvailable(String rideFrom,String rideTo,int noOfSeatsAvailable) {
		return rideSchedulesRepository.findRideByRideFromAndRideToAndNoOfSeatsAvailable(rideFrom, rideTo, noOfSeatsAvailable);
	}

	@Override
	public RideSchedulesDto insertRide(RideSchedulesDto rideSchedulesDto)
			throws VehicleNotApprovedException, MaximumCapacityExceededException {
		// TODO Auto-generated method stub
		Vehicles vehicles=vehiclesRepository.findByRegistrationNo(rideSchedulesDto.getVehicleRegistrationNo());
		if(!vehicles.getInspectionStatus().equalsIgnoreCase("Approved")){
			throw new VehicleNotApprovedException();
		}
		RideSchedules rideSchedules=RideSchedulesMapper.rideschedulesDtoToRideSchedule(rideSchedulesDto);
		RideSchedules saveRide= rideSchedulesRepository.save(rideSchedules);
		
		RideSchedulesDto saveRideDto=RideSchedulesMapper.rideschedulesToRideScheduleDto(saveRide);
		return saveRideDto;

		
	}
	// b.Insert a new RideSchedule

	
	

}
