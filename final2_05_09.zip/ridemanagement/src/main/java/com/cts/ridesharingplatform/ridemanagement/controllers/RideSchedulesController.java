package com.cts.ridesharingplatform.ridemanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaximumCapacityExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.VehicleNotApprovedException;
import com.cts.ridesharingplatform.ridemanagement.services.RideSchedulesService;


@RestController
public class RideSchedulesController {

	@Autowired
	private RideSchedulesService rideSchedulesService;
	
	// Returns the rideschedules details
	@GetMapping("/api/rideschedules")
	public List<RideSchedules> getAllRideSchedules() {
		return this.rideSchedulesService.getAllRideSchedules();
	}
	// b. Insert a new ride schedule
	@PostMapping(path="/schedule",consumes = "application/json")
	public ResponseEntity<RideSchedulesDto> insertRide(@RequestBody RideSchedulesDto rideSchedulesDto)throws VehicleNotApprovedException,MaximumCapacityExceededException{
		
		RideSchedulesDto newRide=rideSchedulesService.insertRide(rideSchedulesDto);
		return new ResponseEntity<>(newRide,HttpStatus.CREATED);
	}

	// Search for a ride using id
	@GetMapping("/api/rideschedules/{id}")
	public RideSchedules getRideById(@PathVariable int id) {
		return this.rideSchedulesService.getRideById(id);
	}

	// c.Search a ride schedule by using ridefrom,rideto,noofseats
	@GetMapping("/api/rides/{ridefrom}/{rideto}/{noofseatsavailable}")
	public RideSchedules getRideByRideFromAndRideToAndNoOfSeatsAvailable(@PathVariable String ridefrom,
			@PathVariable String rideto, @PathVariable int noofseatsavailable) {
		return this.rideSchedulesService.getRideByRideFromAndRideToAndNoOfSeatsAvailable(ridefrom, rideto,
				noofseatsavailable);
	}

}
