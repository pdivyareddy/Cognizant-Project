package com.cts.ridesharingplatform.ridemanagement.services;

import java.util.List;

import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoVehicleFound;

public interface VehiclesService {

	List<Vehicles> getAllVehicles();
	
	double calculateFare(FareParametersDto fareParametersDto) throws NoVehicleFound;
}
