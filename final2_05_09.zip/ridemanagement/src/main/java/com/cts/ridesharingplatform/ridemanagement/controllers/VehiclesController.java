package com.cts.ridesharingplatform.ridemanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoVehicleFound;
import com.cts.ridesharingplatform.ridemanagement.services.VehiclesService;


@RestController
public class VehiclesController {
	@Autowired
	private VehiclesService  vehiclesService ;
	// Returns the Vehicles details
		@GetMapping("/api/vehicles")
		public List<Vehicles> getAllVehicles() {
		return this.vehiclesService.getAllVehicles();

}
		
		@GetMapping("/rides/calculatefare")
		public ResponseEntity<Double> calculateFare(@RequestBody FareParametersDto fareParametersDto) throws NoVehicleFound{
			double fare=vehiclesService.calculateFare(fareParametersDto);
			return ResponseEntity.ok(fare);
		}
}
