package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ridesharingplatform.ridemanagement.dtos.DistancesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Distances;
import com.cts.ridesharingplatform.ridemanagement.mapper.DistancesMapper;
import com.cts.ridesharingplatform.ridemanagement.repos.DistancesRepository;
import com.cts.ridesharingplatform.ridemanagement.services.DistancesService;


@Service
public class DistancesImpl implements DistancesService{
	
	@Autowired
	DistancesRepository distancesRepository;
	
	public List<DistancesDto> getAllDistances(){
		
		List<Distances> disAll= distancesRepository.findAll();
		return disAll.stream().map(DistancesMapper::distancesToDistancesDto).collect(Collectors.toList());
		
	}

}
