package com.cts.ridesharingplatform.ridemanagement.services;

import java.util.List;

import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaximumCapacityExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.VehicleNotApprovedException;

public interface RideSchedulesService {

	List<RideSchedules> getAllRideSchedules();

	// b.Insert a new RideSchedule
	RideSchedulesDto insertRide(RideSchedulesDto rideSchedulesDto) throws VehicleNotApprovedException,MaximumCapacityExceededException;

	RideSchedules getRideById(int ID);

	//c. Search a ride schedule by using from to and available seats
	RideSchedules getRideByRideFromAndRideToAndNoOfSeatsAvailable(String rideFrom, String rideTo,
			int noOfSeatsAvailable);

}
