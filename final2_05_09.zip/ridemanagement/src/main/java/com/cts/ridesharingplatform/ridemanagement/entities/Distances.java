package com.cts.ridesharingplatform.ridemanagement.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Id;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "distances")
public class Distances {
	@Id
	@Column(name = "id")
	private int Id;

	@Column(name = "fromm")
	private String Fromm;
	@Column(name = "too")
	private String Too;
	@Column(name = "distancesinkms")
	private int DistanceInKms;

}
