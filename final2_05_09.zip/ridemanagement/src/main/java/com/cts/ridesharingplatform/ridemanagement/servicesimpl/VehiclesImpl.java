package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoVehicleFound;
import com.cts.ridesharingplatform.ridemanagement.repos.VehiclesRepository;
import com.cts.ridesharingplatform.ridemanagement.services.VehiclesService;

@Service
public class VehiclesImpl implements VehiclesService{
	
	@Autowired
	VehiclesRepository vehiclesRepository;

	@Override
	public List<Vehicles> getAllVehicles() {
	
		return (List<Vehicles>)vehiclesRepository.findAll();
	}

	@Override
	public double calculateFare(FareParametersDto fareParametersDto) throws NoVehicleFound {
		int distance = fareParametersDto.getDistance();
		String registrationNo = fareParametersDto.getRegistrationNo();
		Vehicles vehicle = vehiclesRepository.findByRegistrationNo(registrationNo);
		if(vehicle==null) {
			throw new NoVehicleFound();
		}

		int fareperkm = vehicle.getFarePerKm();
		return fareperkm * distance;
	}
	

}
