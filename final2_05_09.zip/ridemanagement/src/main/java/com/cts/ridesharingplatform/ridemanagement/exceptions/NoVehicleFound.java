package com.cts.ridesharingplatform.ridemanagement.exceptions;



public class NoVehicleFound extends Exception {
	
	private static final long serialVersionUID = 1L;
	private String message;
	public  NoVehicleFound(){}
	public NoVehicleFound(String message) {
		this.message=message;
	}
	public String getMessage() {
		return this.message;
	}
	}