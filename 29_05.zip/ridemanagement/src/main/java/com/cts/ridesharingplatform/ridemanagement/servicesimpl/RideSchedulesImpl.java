package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Distances;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaximumCapacityExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoVehicleFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.VehicleNotApprovedException;
import com.cts.ridesharingplatform.ridemanagement.mapper.RideSchedulesMapper;
import com.cts.ridesharingplatform.ridemanagement.repos.DistancesRepository;
import com.cts.ridesharingplatform.ridemanagement.repos.RideSchedulesRepository;
import com.cts.ridesharingplatform.ridemanagement.repos.VehiclesRepository;
import com.cts.ridesharingplatform.ridemanagement.services.RideSchedulesService;


@Service
public class RideSchedulesImpl implements RideSchedulesService {

	@Autowired
	RideSchedulesRepository rideSchedulesRepository;
	@Autowired
	VehiclesRepository vehiclesRepository;
	@Autowired
	DistancesRepository distancesRepository;

	// Lists all ride schedules
	public List<RideSchedules> getAllRideSchedules() {
		return (List<RideSchedules>) rideSchedulesRepository.findAll();
	}


	
	// Gives ride schedules details by using Id
	@Override
	public RideSchedules getRideById(int ID) {
		return rideSchedulesRepository.findById(ID).get();
	}

	// b. Create a new ride

	@Override
	public RideSchedulesDto createRide(RideSchedulesDto rideSchedulesDto)
			throws VehicleNotApprovedException, MaximumCapacityExceededException,NoVehicleFoundException {
		// TODO Auto-generated method stub
		Vehicles vehicles=vehiclesRepository.findByRegistrationNo(rideSchedulesDto.getVehicleRegistrationNo());
		if(vehicles==null) {
			throw new NoVehicleFoundException("No vehicle found with the given regitration number");
		}
		else if(!vehicles.getInspectionStatus().equalsIgnoreCase("Approved")){
			throw new VehicleNotApprovedException();
	
		}
		else if(rideSchedulesDto.getNoOfSeatsAvailable()>vehicles.getMaxSeats()) {
			throw new MaximumCapacityExceededException();
		}
		
		else {
		RideSchedules rideSchedules=RideSchedulesMapper.rideschedulesDtoToRideSchedule(rideSchedulesDto);
		RideSchedules saveRide= rideSchedulesRepository.save(rideSchedules);
		
		RideSchedulesDto saveRideDto=RideSchedulesMapper.rideschedulesToRideScheduleDto(saveRide);
		return saveRideDto;
		}
		
	}
	
	

	@Override
	public int calculateFare(FareParametersDto fareParametersDto) throws NoRideFoundException {
		// TODO Auto-generated method stub
		String registrationNo = fareParametersDto.getRegistrationNo();
		RideSchedules rideSchedules=rideSchedulesRepository.findByVehicleRegistrationNo(registrationNo);
				if(rideSchedules==null) {
					throw new NoRideFoundException();
				}
		Vehicles vehicle = vehiclesRepository.findByRegistrationNo(registrationNo);
				if(vehicle==null) {
					throw new NoRideFoundException();
				}
				String ridefrom=rideSchedules.getRideFrom();
				String rideto=rideSchedules.getRideTo();
		Distances distance=distancesRepository.findDistanceInKmsBydistancefromAndDistanceTo(ridefrom,rideto);
		int fareperkm = vehicle.getFarePerKm();
		int dis=distance.getDistanceInKms();
		return fareperkm*dis;
				
		
	}
	
	
}


