package com.cts.ridesharingplatform.ridemanagement.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.dtos.DistancesDto;
import com.cts.ridesharingplatform.ridemanagement.services.DistancesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api")
public class DistancesController {
	
	@Autowired
	private DistancesService distancesService;
	
	
	//a. Fetch all the Distances Details
	// EndPoint 1
	
	@GetMapping("/distances")
	public ResponseEntity<List<DistancesDto>> getAllDistances(){
		log.info("Request for returning distances");
		List<DistancesDto> distances=distancesService.getAllDistances();
		log.info("Response generated for returning distances!");
		return new ResponseEntity<>(distances,HttpStatus.OK);
	}
	
	

}
