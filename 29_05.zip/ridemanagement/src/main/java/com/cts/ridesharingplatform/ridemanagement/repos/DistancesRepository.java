package com.cts.ridesharingplatform.ridemanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.ridesharingplatform.ridemanagement.entities.Distances;

public interface DistancesRepository extends JpaRepository<Distances,Integer> {

	Distances findDistanceInKmsBydistancefromAndDistanceTo(String distancefrom,String distanceto);

}
