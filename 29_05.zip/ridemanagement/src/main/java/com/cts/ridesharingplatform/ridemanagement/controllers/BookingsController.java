package com.cts.ridesharingplatform.ridemanagement.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.dtos.SearchCriteriaDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Bookings;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BadSearchCriteriaException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingAlreadyExistException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingNotFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaxSeatsPerRideExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;
import com.cts.ridesharingplatform.ridemanagement.services.BookingsService;
import com.cts.ridesharingplatform.ridemanagement.services.RideSchedulesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api")
public class BookingsController {

	@Autowired
	private BookingsService bookingsService;
	@Autowired
	RideSchedulesService rideSchedulesService;
	

	@GetMapping(path="/bookings")
	public List<Bookings> getAllBookings() {
		log.info("Request for getting all bookings");
		return this.bookingsService.getAllBookings();
		
	}
	
	// ENDPOINT 4
	
	@GetMapping(path="rides/search")
	public List<RideSchedulesDto> searchRideSchedule(@Valid @RequestBody SearchCriteriaDto searchCriteriaDto) throws BadSearchCriteriaException ,NoRideFoundException{
			log.info("Request for searching ride schedules");
			List<RideSchedulesDto> rides=bookingsService.searchRideSchedule(searchCriteriaDto);
			if(rides.isEmpty()) {
				throw new NoRideFoundException();
			}
			return rides;
		
	}
	// ENDPOINT 5
	// d.Insert a new booking and get the status code and bookingId if the booking is created
	
	@PostMapping(path = "/rides/book", consumes = "application/json")
	public ResponseEntity<Integer> createBooking(@RequestBody Bookings bookings) throws BookingAlreadyExistException,MaxSeatsPerRideExceededException {
		log.info("Request for adding new booking");
		Bookings booking = this.bookingsService.createBooking(bookings);
		int bookingid=booking.getBookingId();
		log.info("Response generated for adding new booking");
		return new ResponseEntity<Integer>(bookingid, HttpStatus.CREATED);
	}

	
	// e.Search existing bookings for user   
	@GetMapping("/search/{rideruserid}")
	public ResponseEntity<List<Bookings>> searchBookingByRiderUserId(@PathVariable int rideruserid) throws BookingNotFoundException {
		log.info("Request for searching Booking by user Id");
		List<Bookings> bookings=bookingsService.searchBookingByRiderUserId(rideruserid);
		log.info("Response generated searching Booking");
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}
	
	

}
