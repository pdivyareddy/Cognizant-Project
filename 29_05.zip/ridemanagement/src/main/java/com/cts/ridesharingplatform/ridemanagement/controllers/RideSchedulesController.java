package com.cts.ridesharingplatform.ridemanagement.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaximumCapacityExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoVehicleFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.VehicleNotApprovedException;
import com.cts.ridesharingplatform.ridemanagement.services.RideSchedulesService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("/api")
public class RideSchedulesController {

	@Autowired
	private RideSchedulesService rideSchedulesService;
	
	
	// Returns the ride schedules details
	@GetMapping("/rideschedules")
	public List<RideSchedules> getAllRideSchedules() {
		log.info("Request gor getting all rideschedules");
		return this.rideSchedulesService.getAllRideSchedules();
	}
	
	// ENDPOINT 2
	
	@GetMapping("/rides/calculatefare")
	public ResponseEntity<Double> calculateFare(@RequestBody FareParametersDto fareParametersDto) throws NoRideFoundException{
		log.info("Request for calculating fare");
		double fare=rideSchedulesService.calculateFare(fareParametersDto);
		return ResponseEntity.ok(fare);
	}
	
	//ENDPOINT 3
	
	@PostMapping(path="rides/schedule",consumes = "application/json")
	public ResponseEntity<RideSchedulesDto> insertRide(@Valid @RequestBody RideSchedulesDto rideSchedulesDto)throws VehicleNotApprovedException,MaximumCapacityExceededException,NoVehicleFoundException{
		log.info("Request for inserting a new ride");
		RideSchedulesDto newRide=rideSchedulesService.createRide(rideSchedulesDto);
		log.info("Response Generated for inserting a new ride");
		return new ResponseEntity<>(newRide,HttpStatus.CREATED);
	}

	// Search for a ride using id
	@GetMapping("/rideschedules/{id}")
	public RideSchedules getRideById(@PathVariable int id) {
		log.info("Request for getting ride by ID: {}", id);
		return this.rideSchedulesService.getRideById(id);
	}
	

	
	
}
