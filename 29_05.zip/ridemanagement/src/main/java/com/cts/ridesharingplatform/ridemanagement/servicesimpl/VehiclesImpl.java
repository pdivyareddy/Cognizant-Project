package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
//import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
//import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;
//import com.cts.ridesharingplatform.ridemanagement.repos.DistancesRepository;
//import com.cts.ridesharingplatform.ridemanagement.repos.RideSchedulesRepository;
import com.cts.ridesharingplatform.ridemanagement.repos.VehiclesRepository;
import com.cts.ridesharingplatform.ridemanagement.services.VehiclesService;

@Service
public class VehiclesImpl implements VehiclesService {

	@Autowired
	VehiclesRepository vehiclesRepository;


	@Override
	public List<Vehicles> getAllVehicles() {

		return (List<Vehicles>) vehiclesRepository.findAll();
	}

	/*
	 * @Override public double calculateFare(FareParametersDto fareParametersDto)
	 * throws NoRideFoundException { int distance = fareParametersDto.getDistance();
	 * String registrationNo = fareParametersDto.getRegistrationNo(); Vehicles
	 * vehicle = vehiclesRepository.findByRegistrationNo(registrationNo);
	 * if(vehicle==null) { throw new NoRideFoundException(); } //RideSchedules
	 * rideSchedules=rideSchedulesRepository.findByVehicleRegistrationNo(
	 * registrationNo); //if(rideSchedules==null) { // throw new
	 * NoRideFoundException(); //} //String ridefrom=rideSchedules.getRideFrom();
	 * //String rideto=rideSchedules.getRideTo();
	 * 
	 * int fareperkm = vehicle.getFarePerKm(); return fareperkm * distance; }
	 */

}
