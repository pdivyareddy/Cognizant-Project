package com.cts.ridesharingplatform.ridemanagement.services;

import java.util.List;

import com.cts.ridesharingplatform.ridemanagement.dtos.DistancesDto;

public interface DistancesService {
	
List<DistancesDto> getAllDistances();

}
