package com.cts.ridesharingplatform.ridemanagement.services;

import java.util.List;

import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.dtos.SearchCriteriaDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Bookings;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BadSearchCriteriaException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingAlreadyExistException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingNotFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaxSeatsPerRideExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;

public interface BookingsService {
	List <Bookings> getAllBookings();
	
	// d.Insert a new booking
	Bookings createBooking(Bookings bookings)throws BookingAlreadyExistException,MaxSeatsPerRideExceededException;
	
	//e.Search existing bookings for user
	List<Bookings> searchBookingByRiderUserId(int riderUserId)throws BookingNotFoundException;
	
	//c. Search a ride schedule by using from to  available seats minimum fare and maximum fare
	List<RideSchedulesDto> searchRideSchedule(SearchCriteriaDto searchCriteria)throws BadSearchCriteriaException,NoRideFoundException ;


}
