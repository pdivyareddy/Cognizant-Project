package com.cts.ridesharingplatform.ridemanagement.dtos;


import java.time.LocalDate;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RideSchedulesDto {
	private int ID;
	private String rideFrom;
	private String rideTo;
	private LocalDate rideStartsOn;
	private LocalTime rideTime;
	private int rideFare;
	private String vehicleRegistrationNo;
	private int motoristUserId;
	private int noOfSeatsAvailable;
	

}
