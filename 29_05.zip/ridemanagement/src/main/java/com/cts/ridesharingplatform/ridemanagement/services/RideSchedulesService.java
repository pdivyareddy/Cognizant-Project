package com.cts.ridesharingplatform.ridemanagement.services;

import java.util.List;

import com.cts.ridesharingplatform.ridemanagement.dtos.FareParametersDto;
import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaximumCapacityExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoVehicleFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.VehicleNotApprovedException;


public interface RideSchedulesService {

	List<RideSchedules> getAllRideSchedules();
	
	RideSchedules getRideById(int ID);

	// b. create a new Ride
	RideSchedulesDto createRide(RideSchedulesDto rideSchedulesDto) throws VehicleNotApprovedException,MaximumCapacityExceededException,NoVehicleFoundException;


//e.Calculate Fare
	int calculateFare(FareParametersDto fareParametersDto) throws NoRideFoundException;
}
