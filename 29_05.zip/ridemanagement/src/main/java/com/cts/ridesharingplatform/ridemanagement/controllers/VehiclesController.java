package com.cts.ridesharingplatform.ridemanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;
import com.cts.ridesharingplatform.ridemanagement.services.VehiclesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api")
public class VehiclesController {
	@Autowired
	private VehiclesService vehiclesService;

	// Returns the Vehicles details
	@GetMapping("/vehicles")
	public List<Vehicles> getAllVehicles() {
		log.info("Request for getting all vehicles details is sent");
		return this.vehiclesService.getAllVehicles();

	}
	/*
	 * //Calculates fare for a ride.
	 * 
	 * @GetMapping("/rides/calculatefare") public ResponseEntity<Double>
	 * calculateFare(@RequestBody FareParametersDto fareParametersDto) throws
	 * NoRideFoundException{ double
	 * fare=vehiclesService.calculateFare(fareParametersDto); return
	 * ResponseEntity.ok(fare); }
	 */
}
