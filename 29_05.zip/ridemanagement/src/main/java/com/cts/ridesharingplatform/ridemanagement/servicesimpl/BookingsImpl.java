package com.cts.ridesharingplatform.ridemanagement.servicesimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ridesharingplatform.ridemanagement.dtos.RideSchedulesDto;
import com.cts.ridesharingplatform.ridemanagement.dtos.SearchCriteriaDto;
import com.cts.ridesharingplatform.ridemanagement.entities.Bookings;
import com.cts.ridesharingplatform.ridemanagement.entities.RideSchedules;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BadSearchCriteriaException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingAlreadyExistException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.BookingNotFoundException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.MaxSeatsPerRideExceededException;
import com.cts.ridesharingplatform.ridemanagement.exceptions.NoRideFoundException;
import com.cts.ridesharingplatform.ridemanagement.mapper.RideSchedulesMapper;
import com.cts.ridesharingplatform.ridemanagement.repos.BookingsRepository;
import com.cts.ridesharingplatform.ridemanagement.repos.RideSchedulesRepository;
import com.cts.ridesharingplatform.ridemanagement.services.BookingsService;


@Service
public class BookingsImpl implements BookingsService {

	@Autowired
	BookingsRepository bookingsRepository;
	
	@Autowired
	RideSchedulesRepository rideSchedulesRepository;
	

	@Override
	public List<Bookings> getAllBookings() {
		// TODO Auto-generated method stub
		return (List<Bookings>) bookingsRepository.findAll();
	}

	// d.Insert a new booking
	@Override
	public Bookings createBooking(Bookings bookings)
			throws BookingAlreadyExistException, MaxSeatsPerRideExceededException {
		// TODO Auto-generated method stub
		Bookings boo;
		int seats = bookings.getNoOfSeats();
		if (bookingsRepository.existsById(bookings.getBookingId())) {
			throw new BookingAlreadyExistException();
		}
		else {
			if(seats <= 2) {
				boo = bookingsRepository.save(bookings);
			} 
			else {
				throw new MaxSeatsPerRideExceededException();
			}
		}
		return boo;

	}

	@Override
	public List<Bookings> searchBookingByRiderUserId(int riderUserId) throws BookingNotFoundException {
		List<Bookings> bookings=bookingsRepository.findByRiderUserId(riderUserId);
		if(bookings.isEmpty()) {
			throw new BookingNotFoundException();
		}
		
		return bookings;
	}

	@Override
	public List<RideSchedulesDto> searchRideSchedule(SearchCriteriaDto searchCriteria)
			throws BadSearchCriteriaException, NoRideFoundException {
		if(searchCriteria.getDistance_from().isEmpty() ||searchCriteria.getDistance_to().isEmpty()||
				searchCriteria.getMin_price()==0||searchCriteria.getMax_price()==0||searchCriteria.getAvailable_seats()==0) {
			throw new BadSearchCriteriaException();
		}
	
		List<RideSchedules> rides=rideSchedulesRepository.findRideByRideFromAndRideToAndRideFareLessThanEqualAndRideFareGreaterThanEqualAndNoOfSeatsAvailableGreaterThanEqual(
				searchCriteria.getDistance_from(),
				searchCriteria.getDistance_to(),
				searchCriteria.getMax_price(),
				searchCriteria.getMin_price(),
				searchCriteria.getAvailable_seats()
				);
		//System.out.println(rides);
		return rides.stream().map(RideSchedulesMapper::rideschedulesToRideScheduleDto).collect(Collectors.toList());
	}

	
	

}
