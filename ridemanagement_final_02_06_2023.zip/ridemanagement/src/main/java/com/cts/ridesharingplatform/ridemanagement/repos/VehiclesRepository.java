package com.cts.ridesharingplatform.ridemanagement.repos;
import org.springframework.data.repository.CrudRepository;

import com.cts.ridesharingplatform.ridemanagement.entities.Vehicles;


public interface VehiclesRepository extends CrudRepository<Vehicles, String>{
	Vehicles findByRegistrationNo(String registrationNo);

}
